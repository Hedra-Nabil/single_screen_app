class Note {
  final String content;
  const Note(this.content);
}
